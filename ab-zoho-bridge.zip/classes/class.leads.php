<?php
/**
 * Plugin zoho leads controller class.
 * 
 * @since   2.0.0
 */

if( !class_exists( 'Zoho_Leads' ) ){

    class Zoho_Leads{

        function add(){


        }

        function update( $id ){

            
        }

        function delete( $id ){

        }

        function get( $id ){

        }
    }
}
?>